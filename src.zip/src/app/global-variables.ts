export class globalvariables{
    public static totalCount:number=0;
    public static grandTotal:number=0;
    public static item_list: Array<any>=[];
    public static selected: Array<number> = new Array();
    // constructor(){
    // this.product_list = [
    //     { id: 1, pname: 'Idli', price: 30 , comments:"Idli is a soft, pillowy steamed savory cake made from rice and lentil batter, a healthy breakfast",src:"assets/images/idli.png"},
    //     { id: 2, pname: 'Dosa', price: 35 ,comments:"Thin pancake made from a fermented batter predominantly consisting of lentils and rice",src:"assets/images/dosa.png"},
    //     { id: 3, pname: 'Vada', price: 40 ,comments:"Vada or bada are made from are a kind of deep fried savory snack mostly made with lentils, spices and herbs",src:"assets/images/vada.jpg"},
    //     { id: 4, pname:'Puliyogare', price:50, comments:"Pulihora or simply tamarind rice, is a very common and traditional rice preparation in the South Indian states",src:"assets/images/puliohara.png"},
    //     { id: 5, pname:'Poha', price:35, comments:"Poha, also known as pauwa, chira, or aval, is flattened rice originating from the Indian subcontinent.",src:"assets/images/poha.png"},
    //     { id: 6, pname:'Upma', price:40, comments:"Uppittu is a dish originating from the Indian subcontinent, cooked as a thick porridge from coarse rice flour.",src:"assets/images/upma.png"},
    //     { id: 7, pname: 'Tea', price: 10, comments:"Tea is an aromatic beverage prepared by pouring hot or boiling water over cured leaves of Camellia sinensis",src:"assets/images/tea.png"},
    //     { id: 8, pname: 'Coffee', price: 15, comments:" Coffee is a beverage brewed from the roasted and ground seeds of the tropical evergreen coffee plant",src:"assets/images/coffee.png"}
    // ];
    // }
    
}