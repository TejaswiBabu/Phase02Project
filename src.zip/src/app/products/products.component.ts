import { variable } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';
import { globalvariables } from '../global-variables';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
    product_list: Array<any>;
    sum:number = 0;
    count:number=0;
    constructor(){
       globalvariables.item_list = [
         { id: 1, pname: 'Chicken Biryani', price: 110 , comments:"Chicken Biryani is a savory chicken and rice dish that includes layers of chicken, rice, and aromatics that are steamed together.",src:"https://www.cubesnjuliennes.com/wp-content/uploads/2020/07/Chicken-Biryani-Recipe-500x500.jpg"},
         { id: 2, pname: 'Fried rice', price: 75 ,comments:"Fried rice is a dish of cooked rice that is stir-fried in a frying pan and  mixed with ingredients such as eggs, vegetables",src:"https://www.madhuseverydayindian.com/wp-content/uploads/2020/06/burnt-garlic-veg-fried-rice-recipe.jpg"},
         { id: 3, pname: 'Idly', price: 60 ,comments:"A type of savoury rice cake, originating from the Indian subcontinent, popular as breakfast foods in Southern India",src:"https://chakriskitchen.com/wp-content/uploads/2018/12/Idly19.jpg"},
         { id: 4, pname:'Poori', price:80, comments:"A delicious dhaba-style north Indian dish of chickpeas in a delicious red sauce of onions and tomato with a puffy, flaky bread",src:"assets/images/chola bhatura.jfif"},
         { id: 5, pname:'Paneer makhani', price:95, comments:"A slightly sweet creamy dish of paneer, in which the gravy is prepared usually with butter.",src:"https://veggiedesserts.com/wp-content/uploads/2021/04/paneer-butter-masala-sq.jpg"},
         { id: 6, pname:'Momos', price:60, comments:"A  type of steamed dumpling with some form of filling of mixed vegetables, traditional dish of nepal.",src:"https://s3-ap-south-1.amazonaws.com/betterbutterbucket-silver/ritu-arora020180111172007064.jpeg"},
         { id: 7, pname: 'Dosa', price: 50, comments:"A dosa is a thin pancake or crepe South India, made from fermented batter consisting of lentils and rice",src:"https://www.saveur.com/uploads/2019/02/08/LG3PBW4LR36GTAUPOQIVINRVZA.jpg"},
         { id: 8, pname: 'Cappuccino', price: 75, comments:" A fish fry is a meal containing battered or breaded fried fish. It usually also includes lemon slices, tartar sauce.",src:"https://res.cloudinary.com/swiggy/image/upload/f_auto,q_auto,fl_lossy/mxbxocvfbrln4ieykxil"}
     ];
     this.product_list=globalvariables.item_list;
    }
     addtocart(id:number){
      globalvariables.grandTotal = globalvariables.grandTotal + globalvariables.item_list[id-1].price;
      globalvariables.totalCount=globalvariables.totalCount+1;
      globalvariables.selected.push(id);


      this.sum = globalvariables.grandTotal; 
      this.count = globalvariables.totalCount; 
     }
    ngOnInit(): void {
    }

}
