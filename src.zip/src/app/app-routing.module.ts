import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';

import { LoginComponent } from './login/login.component';
import { CartDisplayComponent } from './cart-display/cart-display.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { CheckoutsuccessComponent } from './checkoutsuccess/checkoutsuccess.component';

import { RegisterComponent } from './register/register.component';
import { ProductsComponent } from './products/products.component';
const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'login',
    component:LoginComponent,
    pathMatch: 'full'
  },
  {
    path: 'products',
    component:ProductsComponent,
    pathMatch:'full'
  },
  {
    path: 'cart-display',
    component:CartDisplayComponent,
    pathMatch:'full'
  },
  {
    path: 'register',
    component:RegisterComponent,
    pathMatch: 'full'
  },
  {
    path: 'checkout',
    component:CheckoutComponent,
    pathMatch: 'full'
  },
  {
    path: 'checkoutsuccess',
    component:CheckoutsuccessComponent,
    pathMatch: 'full'
  },

  {
    path: 'admin-login',
    component:AdminLoginComponent,
    pathMatch: 'full'
  },
  {
    path: 'admin-home',
    component:AdminHomeComponent,
    pathMatch: 'full'
  },
  { path: '**', redirectTo: '/login', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
